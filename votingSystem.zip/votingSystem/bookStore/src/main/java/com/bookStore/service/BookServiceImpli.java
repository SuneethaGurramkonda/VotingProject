package com.bookStore.service;

import java.awt.print.Book;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.bookStore.repository.BookRepositoty;
@Service
@Component
@EnableJpaRepositories(basePackages = "com.bookStore")
public class BookServiceImpli  implements BookService
{
	@Autowired
	private BookRepositoty bRepo;
	@Override
	public void save(Book b) 
	{
		bRepo.save(b);
	}
}
