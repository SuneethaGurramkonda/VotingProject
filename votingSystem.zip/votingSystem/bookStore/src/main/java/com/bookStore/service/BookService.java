package com.bookStore.service;

import java.awt.print.Book;

public interface BookService 
{
	public void save(Book b) ;
}
