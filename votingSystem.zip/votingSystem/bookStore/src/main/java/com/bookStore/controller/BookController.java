package com.bookStore.controller;

import java.awt.print.Book;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.servlet.error.ErrorController;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import com.bookStore.service.BookService;

@Controller
public class BookController  
{
	 @Autowired
	 private BookService service;
	
	@GetMapping("/")
	public String home() 
	{
		return "home";
	}
	
	 @GetMapping("/book_register")
	 public String bookRegister()
	 {
		 return "bookRegister";
		 
	 }
	 
	 @GetMapping("/available_books")
	 public String getAllBooks() 
	 {
		 return "bookList";
	 }
	
	 
	 @PostMapping("/save")
	 public String addBook(@ModelAttribute Book b)
	 {
		 service.save(b);
		 return "available_books";
	 }
}

