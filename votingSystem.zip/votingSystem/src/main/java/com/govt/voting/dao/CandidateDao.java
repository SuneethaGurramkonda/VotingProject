package com.govt.voting.dao;

import java.util.List;

import com.govt.voting.entity.Candidate;

public interface CandidateDao {

	List<Candidate> getAllCandidates();
	void addNewCandidate(Candidate cand);

	void doVoting(String candidate);

	Candidate getCandidate(String candidate);


	

}
