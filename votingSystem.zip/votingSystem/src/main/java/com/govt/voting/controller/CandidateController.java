package com.govt.voting.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.govt.voting.dao.CandidateDao;
import com.govt.voting.dao.VoterDao;
import com.govt.voting.entity.Candidate;
import com.govt.voting.entity.Voter;
@Controller
public class CandidateController 
{
	@Autowired
	private CandidateDao dao;
	@RequestMapping("/addCandidate")
	public String addCandidate(Candidate cand,Model model) 
	{
		String message = "Your Application is Rejected..!!!";
		if(cand.getAge()<24)
		{
			message+="Bcoz Age is not matching...!!!";
		}
		else if(cand.getMonthlyincome()>10000) 
		{
			message+="Bcoz monthly income is more...!!!!";
		}
		else if(cand.getAnnuallyincome()>120000) 
		{
			message+="Bcoz yearly income is more..!!!";
		}
		else if(cand.getTotalproperty()>10000000) 
		{
			message+="Bcoz Total Property is more...!!!";
		}
		else {
			 message = "Your Application Approved..!!!!";
			 dao.addNewCandidate(cand);
			 model.addAttribute("check", true);
			 model.addAttribute("status", message);
			 return "ApplyCandidate";
	}
		model.addAttribute("status", message);
		 model.addAttribute("check", false);
		 return "ApplyCandidate";
	}

	  @Autowired 
	  private VoterDao vdao; 
	  @RequestMapping("/addVote") public String addVote(String voter,String
	  candidate,Model model) { dao.doVoting(candidate); vdao.changeStatus(voter);
	  Candidate ca = dao.getCandidate(candidate); Voter v = vdao.getVoter(voter);
	  model.addAttribute("name", ca.getFirstname()); model.addAttribute("voter", v);
	  model.addAttribute("listOfCan", dao.getAllCandidates());
	  return "VoterLoginPage"; 
	  }
	  
	  @RequestMapping("/viewAllCandidates")
		public String viewAllCandidates(Model model) 
		{
			List<Candidate> cList = dao.getAllCandidates();
			model.addAttribute("allCandidates", cList);
			return "ViewCandidates";
		}
}

