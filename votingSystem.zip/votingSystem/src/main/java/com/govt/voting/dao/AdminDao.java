package com.govt.voting.dao;

import java.util.List;

import com.govt.voting.entity.Admin;

public interface AdminDao {

	boolean validateAdmin(String email, String password);

	Admin getAdmin(String email);

	List<Admin> getAllAdmin();

}
