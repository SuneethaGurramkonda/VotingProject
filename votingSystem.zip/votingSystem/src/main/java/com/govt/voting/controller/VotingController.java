package com.govt.voting.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.govt.voting.dao.CandidateDao;
import com.govt.voting.dao.VoterDao;
import com.govt.voting.entity.Admin;
import com.govt.voting.entity.Candidate;
import com.govt.voting.entity.Voter;

@Controller
public class VotingController
{
	@RequestMapping("/displayHome")
	public String displayHome()
	{
		return "Voter_home";
	}
	
	@Autowired
	private VoterDao dao;
	@RequestMapping("/signup")
	public String signup(Voter voter,Model model)
	{
		dao.addVoter(voter);
		model.addAttribute("message","Registration successful...!!");
		return "NewVoter";
	}
	@Autowired
	private CandidateDao canDao;
	@RequestMapping("/voterLogin")
	public String voterLogin(String email,String password,Model model) 
	{
		boolean status = dao.validateVoter(email,password);
		if(status) 
		{
			Voter vtr = dao.getVoter(email);
			List<Candidate> ls = canDao.getAllCandidates();
			model.addAttribute("voter", vtr);
			model.addAttribute("listOfCan", ls);
			return "VoterLoginPage";
		}
		else 
		{
			model.addAttribute("loginstatus","In-valid Credentials!!");
			return "VoterSignin";
		}
	}
	@RequestMapping("/viewAllVoters")
	public String viewAllVoters(Model model) 
	{
		List<Voter> vList = dao.getAllVoters();
		model.addAttribute("allVoters", vList);
		return "ViewVoters";
	}
	
}