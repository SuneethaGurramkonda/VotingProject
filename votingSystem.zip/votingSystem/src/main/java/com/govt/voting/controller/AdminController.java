package com.govt.voting.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.govt.voting.dao.AdminDao;
import com.govt.voting.dao.CandidateDao;
import com.govt.voting.entity.Admin;
import com.govt.voting.entity.Candidate;
@Controller
public class AdminController 
{
	@Autowired
	private CandidateDao cDao;
	@Autowired
	private AdminDao dao;
	@RequestMapping("/adminLogin")
	public String adminLogin(String email,String password,Model model) 
	{
		boolean status = dao.validateAdmin(email,password);
		if(status) 
		{
			List<Candidate> lcan = cDao.getAllCandidates();
			Admin ad = dao.getAdmin(email);
			model.addAttribute("listOfCan", lcan);
			model.addAttribute("admin", ad);
			return "AdminLoginPage";
		}
		else 
		{
			model.addAttribute("loginstatus","In-valid Credentials!!");
			return "AdminSignin";
		}
	}
	@RequestMapping("/viewAllAdmin")
	public String viewAllAdmin(Model model) 
	{
		List<Admin> aList = dao.getAllAdmin();
		model.addAttribute("allAdmins", aList);
		return "ViewAdmin";
	}
}
